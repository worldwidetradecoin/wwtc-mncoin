World Wide Trade Coin Core 
=====================================

### Coin Specs
<table>
<tr><td>Ticker</td><td>WWTC</td></tr>
<tr><td>Algorithm</td><td>Quark</td></tr>
<tr><td>Block Time</td><td>60 Seconds</td></tr>
<tr><td>Premine</td><td>20,000,000 WWTC</td></tr>
<tr><td>MN Collateral</td><td>1,000 WWTC</td></tr>
<tr><td>Pos/MN rate</td><td>5 : 5</td></tr>
</table>
