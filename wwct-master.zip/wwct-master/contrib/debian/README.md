
Debian
====================
This directory contains files used to package wwtcd/wwtc-qt
for Debian-based Linux systems. If you compile wwtcd/wwtc-qt yourself, there are some useful files here.

## wwtc: URI support ##


wwtc-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install wwtc-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your wwtcqt binary to `/usr/bin`
and the `../../share/pixmaps/wwtc128.png` to `/usr/share/pixmaps`

wwtc-qt.protocol (KDE)

