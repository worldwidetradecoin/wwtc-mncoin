Sample configuration files for:

SystemD: wwtcd.service
Upstart: wwtcd.conf
OpenRC:  wwtcd.openrc
         wwtcd.openrcconf
CentOS:  wwtcd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
